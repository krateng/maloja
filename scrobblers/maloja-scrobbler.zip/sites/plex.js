maloja_scrobbler_selector_playbar = "//div[contains(@class,'PlayerControls')]"


maloja_scrobbler_selector_metadata = ".//div[contains(@class,'PlayerControlsMetadata-container')]"

maloja_scrobbler_selector_title = ".//a[@data-qa-id='metadataTitleLink']/@title"
maloja_scrobbler_selector_artist = ".//span[contains(@class,'MetadataPosterTitle-title')]/a[1]/@title"
maloja_scrobbler_selector_duration = ".//button[@data-qa-id='mediaDuration']/text()[3]"


maloja_scrobbler_selector_control = ".//div[contains(@class,'PlayerControls-buttonGroupCenter')]/button[2]/@title"
