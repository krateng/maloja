maloja_scrobbler_selector_playbar = "//div[@class='now-playing-bar']"


maloja_scrobbler_selector_metadata = ".//div[@class='now-playing-bar__left']"

maloja_scrobbler_selector_title = ".//div[contains(@class,'track-info__name')]//a/text()"
maloja_scrobbler_selector_artists = ".//div[contains(@class,'track-info__artists')]//a"
maloja_scrobbler_selector_artist = "./text()"
maloja_scrobbler_selector_duration = ".//div[@class='playback-bar__progress-time'][2]/text()"


maloja_scrobbler_selector_control = ".//div[contains(@class,'player-controls__buttons')]/div[3]/button/@title"
