maloja_scrobbler_selector_playbar = "//div[@class='now-playing-bar']"


maloja_scrobbler_selector_metadata = ".//div[@class='now-playing-bar__left']"

maloja_scrobbler_selector_title = ".//a[@data-testid='nowplaying-track-link']/text()"
maloja_scrobbler_selector_artists = ".//a[contains(@href,'/artist/')]"
maloja_scrobbler_selector_artist = "./text()"
maloja_scrobbler_selector_duration = ".//div[@class='playback-bar']/div[3]/text()"


maloja_scrobbler_selector_control = ".//div[contains(@class,'player-controls__buttons')]/button[3]/@title"
